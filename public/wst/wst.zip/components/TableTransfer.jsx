import { Transfer, Table } from 'antd'
import difference from 'lodash/difference'
import React from 'react'

class TableTransfer extends React.Component {

    render() {

        const { leftColumns, rightColumns, ...restProps } = this.props

        return (
            <Transfer
                titles={['商品列表', '推荐列表']}
                {...restProps}
                showSelectAll={false}
                listStyle={{ width: "100%", height: 600, overflow: "auto" }}
                // 关闭懒加载
                lazy={false}
            >
                {({
                    direction,
                    filteredItems,
                    onItemSelectAll,
                    onItemSelect,
                    selectedKeys: listSelectedKeys,
                    disabled: listDisabled,
                }) => {
                    const columns = direction === 'left' ? leftColumns : rightColumns;

                    const rowSelection = {
                        getCheckboxProps: item => ({ disabled: listDisabled || item.disabled }),
                        onSelectAll(selected, selectedRows) {
                            const treeSelectedKeys = selectedRows
                                .filter(item => !item.disabled)
                                .map(({ key }) => key);
                            const diffKeys = selected
                                ? difference(treeSelectedKeys, listSelectedKeys)
                                : difference(listSelectedKeys, treeSelectedKeys);
                            onItemSelectAll(diffKeys, selected);
                        },
                        onSelect({ key }, selected) {
                            onItemSelect(key, selected);
                        },
                        selectedRowKeys: listSelectedKeys,
                    };

                    return (
                        <Table
                            rowKey="key"
                            rowSelection={rowSelection}
                            columns={columns}
                            dataSource={filteredItems}
                            pagination={false}
                            size="small"
                        />
                    );
                }}
            </Transfer>
        )
    }

}

export default TableTransfer