import { Component } from 'react'
import { Card, Transfer, Row, Col, Button, Input, Form, Select, message, Table, Tooltip } from 'antd'
import { BulbTwoTone } from '@ant-design/icons'
import GoodsCatCascader from '@/components/WSTCascader/goodsCat'
import TableTransfer from './components/TableTransfer'
import { searchGoods, listQueryByGoods, editGoods } from './services'
import styles from './style.less'

const { Option } = Select;


class RecommendsGoods extends Component {

    constructor(props) {
        super(props)
        this.state = {
            // 被选中的项
            checkData: [],
            // 数据源
            dataSource: [],
            // 右边集合
            targetKeys: [],
            // 搜索商品
            searchGoodsCatIdPath: "",
            key: "",
            // 搜索已推荐商品
            listQueryGoodsCatIdPath: 0,
            listQueryType: "0",
            sortObj: {},
        }
    }

    // 首次加载推荐数据
    componentDidMount() {
        this.listQueryGoodsCatIdPath(0)
    }

    leftTableColumns = [
        {
            dataIndex: 'key',
            width: 50,
            title: 'ID'
        },
        {
            dataIndex: 'title',
            title: '商品名称',
            render: title => {
                return (
                    <span className={styles.nowrap}>
                        <Tooltip title={title}>
                            {title}
                        </Tooltip>
                    </span>
                )
            }
        },
    ]

    rightTableColumns = [
        {
            dataIndex: 'key',
            width: 50,
            title: 'ID'
        },
        {
            dataIndex: 'title',
            title: '商品名称',
            render: title => {
                return (
                    <span className={styles.nowrap}>
                        <Tooltip title={title}>
                            {title}
                        </Tooltip>
                    </span>
                )
            }
        },
        {
            dataIndex: 'dataSort',
            title: '排序',
            width: 50,
            render: (dataSort, row) => {
                return <Input
                    onChange={(val) => {
                        // 取出选中数据
                        let { checkData } = this.state
                        // 遍历寻找更改
                        checkData.map((x, i) => {
                            // key相等将更改
                            if (x.key == row.key) {
                                checkData[i].dataSort = val.target.value
                            }
                        })
                        this.setState({
                            checkData: checkData
                        })
                    }}
                    defaultValue={dataSort}
                />
            }
        },
    ];

    // 改变穿梭
    handleChange = (targetKeys, direction, moveKeys) => {
        const { checkData, dataSource } = this.state;
        if (direction == "left") {
            // 移除选中【从右边移到左边】
            moveKeys.map(m => {
                // 删除选中数据
                let _c = checkData.findIndex(x => x.key == m);
                // 剔除
                _c != -1 && checkData.splice(_c, 1);

                // const _t = targetKeys.findIndex(t => t == dataSource[m].key)

                // // 删除数据源
                // let _d = dataSource.findIndex(x => {
                //     return x.key == m
                // });
                // // 剔除
                // _d != -1 && dataSource.splice(_d, 1);
            })
        } else {
            // 找出选中的项
            targetKeys.map(t => {
                // 找出被选中的数据
                const _t = dataSource.find(x => x.key == t);

                // 已经存在的key将不会加入到checkDate中
                const _c = checkData.findIndex(c => c.key == _t.key)
                _c == -1 && checkData.push(_t)
            })

        }
        console.log(checkData)
        console.log(dataSource)
        console.log("===========================================")
        this.setState({ checkData, targetKeys });
    };

    // 商品搜索
    async searchGoods() {
        const { searchGoodsCatIdPath, key, checkData } = this.state
        if (!searchGoodsCatIdPath) {
            return message.error("请选择一个分类")
        }
        const params = {}
        if (key) {
            params.key = key
        }
        params.goodsCatIdPath = searchGoodsCatIdPath ? searchGoodsCatIdPath : ''
        await searchGoods(params)
            .then(res => {
                const dataSource = [];
                const { status, msg, data } = res;
                const { checkData } = this.state;

                [...data, ...checkData].map(x => {
                    const key = x.goodsId ? x.goodsId : x.dataId
                    const _c = dataSource.findIndex(db => db.key == key)
                    // 不存在相同数据时才将其放进数据源
                    if (_c == -1) {
                        dataSource.push({
                            ...x,
                            key: key,
                            title: `【${x.shopName}】${x.goodsName}`,
                            // 默认排序为0
                            dataSort: x.dataSort ? x.dataSort : 0
                        })
                    }
                })
                this.setState({ dataSource });
            })
            .catch(err => {
                message.error("获取商品数据失败");
            })
    }

    // 选择已推荐商品分类时触发
    listQueryGoodsCatIdPath(v) {
        this.setState({
            listQueryGoodsCatIdPath: v
        }, () => {
            this.listQueryByGoods()
        })

    }

    // 选择已推荐商品类型时触发
    listQueryType(v) {
        this.setState({
            listQueryType: v
        }, () => {
            this.listQueryByGoods()
        })

    }

    // 请求已推荐商品
    async listQueryByGoods() {
        const { listQueryGoodsCatIdPath, listQueryType } = this.state

        const listQueryParams = {}
        listQueryParams.dataType = listQueryType
        listQueryParams.goodsCatId = listQueryGoodsCatIdPath


        await listQueryByGoods(listQueryParams)
            .then(res => {
                const dataSource = []
                // 已选择列
                let targetKeys = []
                const { status, msg, data } = res

                data.map(x => {
                    const key = x.dataId
                    // 添加为已选中列
                    targetKeys.push(key)
                    // 添加数据源（重置）
                    dataSource.push({
                        ...x,
                        key: key,
                        title: `【${x.shopName}】${x.goodsName}`,
                        // 默认排序为0
                        dataSort: x.dataSort
                    })
                })
                this.setState({ dataSource, targetKeys, checkData: dataSource })
            })
            .catch(err => {
                message.error("获取商品数据失败");
            })
    }

    // 保存当前信息
    _save = async () => {
        const { listQueryGoodsCatIdPath, listQueryType, sortObj, checkData } = this.state

        // 从已选数据中取出
        let ids = [];
        let sorts = {}
        checkData.map(x => {
            // 取出id
            ids.push(x.key)
            // 取出排序
            sorts[x.key] = x.dataSort

        })
        ids = ids.join(",")

        const goodsCatId = listQueryGoodsCatIdPath != 0 ? listQueryGoodsCatIdPath : 0
        const params = {}
        // /params.ids = ids
        params.ids = ids
        params.dataType = listQueryType
        params.goodsCatId = goodsCatId
        params.sorts = sorts

        try {
            // 已推荐商品列表
            const res = await editGoods(params)
            if (res.status != 1) {
                return message.error(res.msg)
            }
            message.success(res.msg)
        } catch (e) {
            global.WST.log(e)
        }
    }

    render() {
        return (
            <Card style={{ margin: 0 }}>

                <Card style={{ backgroundColor: "#cce5ff", margin: "0 0 50px 0" }}>
                    <p> <BulbTwoTone /> 操作说明</p>
                    <p>本功能主要用于前台商品展示的推荐设置，例如首页各楼层，猜你喜欢，最新上架，热销商品，推荐商城等等。</p>
                    <p>若未进行过商品的推荐操作，则系统默认按照商品销量、上架时间排序；若有设置过则以设置的商品及排序为主。</p>
                    <p>本功能为扩展功能，开发者可通过组合不同的商品分类和推荐类型在前台进行商品信息的展示</p>
                </Card>

                <Row>
                    <Col span={24}>

                        <Row gutter={[16, 24]}>
                            <Col sm={{ span: 12 }} xs={{ span: 24 }}>
                                <Form layout="inline">
                                    <Form.Item label="分类">
                                        <GoodsCatCascader onChange={v => this.setState({ searchGoodsCatIdPath: v ? v.join("_") : '' })} />
                                    </Form.Item>
                                </Form>
                                <Form layout="inline">
                                    <Form.Item label="搜索">
                                        <Input onChange={v => this.setState({ key: v.target.value })} placeholder="店铺名、商品名称、商品编号、商品货号" />
                                    </Form.Item>
                                    <Form.Item>
                                        <Button type="primary" onClick={() => this.searchGoods()}>
                                            搜索
                                        </Button>
                                    </Form.Item>
                                </Form>
                            </Col>
                            <Col sm={{ span: 12 }} xs={{ span: 24 }}>
                                <Form layout="inline">
                                    <Form.Item label="分类">
                                        <GoodsCatCascader placeholder="不选择即为全部" onChange={v => this.listQueryGoodsCatIdPath(v != 0 ? v[v.length - 1] : 0)} />
                                    </Form.Item>
                                </Form>
                                <Form layout="inline">
                                    <Form.Item label="类型">
                                        <Select defaultValue={this.state.listQueryType} onChange={v => this.listQueryType(v)}>
                                            <Option value='0'>推荐</Option>
                                            <Option value='1'>热销</Option>
                                            <Option value='2'>精品</Option>
                                            <Option value='3'>新品</Option>
                                        </Select>
                                    </Form.Item>
                                </Form>
                            </Col>
                        </Row>

                        <Row gutter={[16, 24]}>
                            <Col>
                                <TableTransfer
                                    style={{ width: "100%", overflow: "auto" }}
                                    dataSource={this.state.dataSource}
                                    targetKeys={this.state.targetKeys}
                                    onChange={this.handleChange}
                                    leftColumns={this.leftTableColumns}
                                    rightColumns={this.rightTableColumns}
                                />

                                <Button type="primary" style={{ marginTop: 10 }} onClick={this._save}>
                                    保存
                                </Button>
                            </Col>
                        </Row>

                    </Col>
                </Row>

            </Card>
        );
    }
}
export default RecommendsGoods;